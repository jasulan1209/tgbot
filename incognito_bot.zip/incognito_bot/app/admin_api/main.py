"""
Admin API — FastAPI приложение с REST и WebSocket.

Endpoints:
  GET  /api/stats          — общая статистика
  GET  /api/users          — список пользователей
  POST /api/users/{id}/ban — забанить/разбанить
  GET  /api/chats          — список чатов
  GET  /api/chats/{id}/messages — сообщения чата
  WS   /ws/events          — realtime события (новый чат, новое сообщение)
"""

import json
import asyncio
from typing import Annotated

from fastapi import FastAPI, Depends, HTTPException, WebSocket, WebSocketDisconnect, Header
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy import select, func, and_
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.database.session import get_session, create_tables
from app.database.models import User, Chat, Message, ChatStatus, UserStatus
from app.database.redis_client import get_redis

app = FastAPI(title="IncognitoBot Admin API", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


# ─── Auth dependency ──────────────────────────────────────────────────────────

async def verify_admin_key(x_admin_key: Annotated[str | None, Header()] = None) -> None:
    if x_admin_key != settings.ADMIN_SECRET_KEY:
        raise HTTPException(status_code=401, detail="Invalid admin key")


AdminDep = Depends(verify_admin_key)


# ─── WebSocket connection manager ─────────────────────────────────────────────

class ConnectionManager:
    def __init__(self) -> None:
        self._connections: list[WebSocket] = []

    async def connect(self, ws: WebSocket) -> None:
        await ws.accept()
        self._connections.append(ws)

    def disconnect(self, ws: WebSocket) -> None:
        self._connections.remove(ws)

    async def broadcast(self, event: dict) -> None:
        dead = []
        for ws in self._connections:
            try:
                await ws.send_text(json.dumps(event))
            except Exception:
                dead.append(ws)
        for ws in dead:
            self._connections.remove(ws)


ws_manager = ConnectionManager()


# ─── Startup ──────────────────────────────────────────────────────────────────

@app.on_event("startup")
async def on_startup() -> None:
    await create_tables()


# ─── Stats ────────────────────────────────────────────────────────────────────

@app.get("/api/stats", dependencies=[AdminDep])
async def get_stats(session: AsyncSession = Depends(get_session)):
    total_users = (await session.execute(select(func.count(User.id)))).scalar()
    total_chats = (await session.execute(select(func.count(Chat.id)))).scalar()
    active_chats = (await session.execute(
        select(func.count(Chat.id)).where(Chat.status == ChatStatus.ACTIVE)
    )).scalar()
    total_messages = (await session.execute(select(func.count(Message.id)))).scalar()

    redis = get_redis()
    queue_size = await redis.zcard("search_queue")

    return {
        "total_users": total_users,
        "total_chats": total_chats,
        "active_chats": active_chats,
        "total_messages": total_messages,
        "users_in_queue": queue_size,
    }


# ─── Users ────────────────────────────────────────────────────────────────────

@app.get("/api/users", dependencies=[AdminDep])
async def list_users(
    limit: int = 50,
    offset: int = 0,
    status: str | None = None,
    session: AsyncSession = Depends(get_session),
):
    query = select(User).order_by(User.created_at.desc()).limit(limit).offset(offset)
    if status:
        query = query.where(User.status == status)
    result = await session.execute(query)
    users = result.scalars().all()
    return [
        {
            "id": u.id,
            "telegram_id": u.telegram_id,
            "internal_id": u.internal_id,
            "nickname": u.nickname,
            "status": u.status.value,
            "admin_level": u.admin_level,
            "total_chats": u.total_chats,
            "total_messages": u.total_messages,
            "created_at": u.created_at.isoformat(),
        }
        for u in users
    ]


@app.post("/api/users/{telegram_id}/ban", dependencies=[AdminDep])
async def ban_user(telegram_id: int, session: AsyncSession = Depends(get_session)):
    result = await session.execute(select(User).where(User.telegram_id == telegram_id))
    user = result.scalar_one_or_none()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    new_status = UserStatus.ACTIVE if user.status == UserStatus.BANNED else UserStatus.BANNED
    user.status = new_status
    await session.commit()

    await ws_manager.broadcast({
        "event": "user_status_changed",
        "telegram_id": telegram_id,
        "status": new_status.value,
    })

    return {"telegram_id": telegram_id, "status": new_status.value}


# ─── Chats ────────────────────────────────────────────────────────────────────

@app.get("/api/chats", dependencies=[AdminDep])
async def list_chats(
    limit: int = 50,
    offset: int = 0,
    active_only: bool = False,
    session: AsyncSession = Depends(get_session),
):
    query = select(Chat).order_by(Chat.started_at.desc()).limit(limit).offset(offset)
    if active_only:
        query = query.where(Chat.status == ChatStatus.ACTIVE)
    result = await session.execute(query)
    chats = result.scalars().all()
    return [
        {
            "id": c.id,
            "user1_id": c.user1_id,
            "user2_id": c.user2_id,
            "status": c.status.value,
            "started_at": c.started_at.isoformat(),
            "closed_at": c.closed_at.isoformat() if c.closed_at else None,
        }
        for c in chats
    ]


@app.get("/api/chats/{chat_id}/messages", dependencies=[AdminDep])
async def get_chat_messages(
    chat_id: int,
    limit: int = 100,
    offset: int = 0,
    session: AsyncSession = Depends(get_session),
):
    result = await session.execute(
        select(Message)
        .where(Message.chat_id == chat_id)
        .order_by(Message.created_at.asc())
        .limit(limit)
        .offset(offset)
    )
    messages = result.scalars().all()
    return [
        {
            "id": m.id,
            "sender_id": m.sender_id,
            "type": m.msg_type.value,
            "content": m.content,
            "created_at": m.created_at.isoformat(),
        }
        for m in messages
    ]


# ─── WebSocket ────────────────────────────────────────────────────────────────

@app.websocket("/ws/events")
async def websocket_events(ws: WebSocket):
    key = ws.headers.get("x-admin-key")
    if key != settings.ADMIN_SECRET_KEY:
        await ws.close(code=1008)
        return

    await ws_manager.connect(ws)
    try:
        while True:
            # Держим соединение живым — ждём пинг от клиента
            await ws.receive_text()
    except WebSocketDisconnect:
        ws_manager.disconnect(ws)


# ─── Функция для бота чтобы слать события в WS ────────────────────────────────

async def notify_new_chat(chat_id: int, user1_id: int, user2_id: int) -> None:
    await ws_manager.broadcast({
        "event": "new_chat",
        "chat_id": chat_id,
        "user1_id": user1_id,
        "user2_id": user2_id,
    })


async def notify_new_message(chat_id: int, sender_id: int, msg_type: str) -> None:
    await ws_manager.broadcast({
        "event": "new_message",
        "chat_id": chat_id,
        "sender_id": sender_id,
        "type": msg_type,
    })
