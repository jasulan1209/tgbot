from aiogram import Router
from aiogram.filters import CommandStart
from aiogram.types import Message

from app.database.repositories.user_repo import UserRepository
from app.database.session import AsyncSessionLocal
from app.bot.keyboards.main import main_menu

router = Router(name="start")


@router.message(CommandStart())
async def cmd_start(message: Message) -> None:
    tg_user = message.from_user
    nickname = tg_user.username or tg_user.full_name

    async with AsyncSessionLocal() as session:
        repo = UserRepository(session)
        user, created = await repo.get_or_create(
            telegram_id=tg_user.id,
            nickname=nickname,
        )

    if created:
        text = (
            f"👋 Добро пожаловать в <b>IncognitoChat</b>!\n\n"
            f"Твой ID: <code>{user.internal_id}</code>\n\n"
            f"Нажми <b>🔍 Найти собеседника</b> чтобы начать анонимный чат."
        )
    else:
        text = (
            f"С возвращением! 👋\n\n"
            f"Твой ID: <code>{user.internal_id}</code>"
        )

    await message.answer(text, reply_markup=main_menu(), parse_mode="HTML")
