import asyncio

from aiogram import Router, F, Bot
from aiogram.types import Message, CallbackQuery

from app.database.models import MessageType
from app.database.repositories.chat_repo import ChatRepository
from app.database.repositories.user_repo import UserRepository
from app.database.redis_client import get_redis
from app.database.session import AsyncSessionLocal
from app.services.matcher import MatchingService
from app.bot.keyboards.main import main_menu, searching_menu, chat_menu, confirm_end_chat

router = Router(name="chat")

# Сколько секунд ждём между попытками матча (polling interval)
MATCH_POLL_INTERVAL = 1.5
MATCH_TIMEOUT = 120  # 2 минуты максимум в очереди


def _get_matching_service(session) -> MatchingService:
    return MatchingService(
        redis=get_redis(),
        chat_repo=ChatRepository(session),
        user_repo=UserRepository(session),
    )


# ─── Поиск собеседника ────────────────────────────────────────────────────────

@router.message(F.text == "🔍 Найти собеседника")
async def start_search(message: Message, bot: Bot) -> None:
    user_id = message.from_user.id

    async with AsyncSessionLocal() as session:
        matcher = _get_matching_service(session)

        # Проверяем — вдруг уже в чате
        if await matcher.is_in_chat(user_id):
            await message.answer("Ты уже в чате! Используй 🚫 Завершить чат.", reply_markup=chat_menu())
            return

        # Добавляем в очередь
        joined = await matcher.join_queue(user_id)
        if not joined:
            await message.answer("⏳ Ты уже в очереди поиска...", reply_markup=searching_menu())
            return

    await message.answer(
        "🔍 Ищем собеседника...\n\nНажми ❌ Отменить поиск если передумал.",
        reply_markup=searching_menu(),
    )

    # Запускаем задачу ожидания матча в фоне
    asyncio.create_task(_wait_for_match(user_id, bot))


async def _wait_for_match(user_id: int, bot: Bot) -> None:
    """
    Фоновая задача: периодически пытается найти пару.
    Если находит — уведомляет обоих участников.
    """
    elapsed = 0.0

    while elapsed < MATCH_TIMEOUT:
        await asyncio.sleep(MATCH_POLL_INTERVAL)
        elapsed += MATCH_POLL_INTERVAL

        async with AsyncSessionLocal() as session:
            matcher = _get_matching_service(session)

            # Если юзер покинул очередь (отмена) — выходим
            if not await matcher.is_in_queue(user_id):
                return

            result = await matcher.try_match(user_id)

        if result:
            # Уведомляем инициатора
            await bot.send_message(
                user_id,
                "✅ Собеседник найден! Можешь писать.\n\nНажми 🚫 Завершить чат чтобы выйти.",
                reply_markup=chat_menu(),
            )
            # Уведомляем партнёра
            await bot.send_message(
                result.partner_id,
                "✅ Собеседник найден! Можешь писать.\n\nНажми 🚫 Завершить чат чтобы выйти.",
                reply_markup=chat_menu(),
            )
            return

    # Таймаут — убираем из очереди
    async with AsyncSessionLocal() as session:
        matcher = _get_matching_service(session)
        await matcher.leave_queue(user_id)

    await bot.send_message(
        user_id,
        "⏰ Не удалось найти собеседника. Попробуй позже.",
        reply_markup=main_menu(),
    )


# ─── Отмена поиска ────────────────────────────────────────────────────────────

@router.message(F.text == "❌ Отменить поиск")
async def cancel_search(message: Message) -> None:
    user_id = message.from_user.id

    async with AsyncSessionLocal() as session:
        matcher = _get_matching_service(session)
        await matcher.leave_queue(user_id)

    await message.answer("🔎 Поиск отменён.", reply_markup=main_menu())


# ─── Завершение чата ──────────────────────────────────────────────────────────

@router.message(F.text == "🚫 Завершить чат")
async def end_chat_request(message: Message) -> None:
    """Просим подтверждение перед завершением."""
    await message.answer(
        "Хочешь завершить чат?",
        reply_markup=confirm_end_chat(),
    )


@router.callback_query(F.data == "end_chat_confirm")
async def end_chat_confirm(callback: CallbackQuery, bot: Bot) -> None:
    user_id = callback.from_user.id
    await callback.message.delete()

    async with AsyncSessionLocal() as session:
        matcher = _get_matching_service(session)
        chat_id = await matcher.get_current_chat_id(user_id)

        if not chat_id:
            await callback.answer("Активный чат не найден.")
            await callback.message.answer("Ты не в чате.", reply_markup=main_menu())
            return

        partner_id = await matcher.end_chat(user_id, chat_id)

    await bot.send_message(user_id, "✅ Чат завершён.", reply_markup=main_menu())

    if partner_id:
        await bot.send_message(
            partner_id,
            "⚠️ Собеседник завершил чат.",
            reply_markup=main_menu(),
        )

    await callback.answer()


@router.callback_query(F.data == "end_chat_cancel")
async def end_chat_cancel(callback: CallbackQuery) -> None:
    await callback.message.delete()
    await callback.answer("Продолжаем чат!")


# ─── Пересылка сообщений ──────────────────────────────────────────────────────

@router.message(F.text & ~F.text.startswith("/") & ~F.text.in_({
    "🔍 Найти собеседника", "👤 Мой профиль",
    "❌ Отменить поиск", "🚫 Завершить чат",
}))
async def relay_text(message: Message, bot: Bot) -> None:
    await _relay_message(message, bot, MessageType.TEXT, message.text)


@router.message(F.photo)
async def relay_photo(message: Message, bot: Bot) -> None:
    file_id = message.photo[-1].file_id  # берём наибольшее качество
    await _relay_message(message, bot, MessageType.PHOTO, file_id)


@router.message(F.video)
async def relay_video(message: Message, bot: Bot) -> None:
    await _relay_message(message, bot, MessageType.VIDEO, message.video.file_id)


@router.message(F.voice)
async def relay_voice(message: Message, bot: Bot) -> None:
    await _relay_message(message, bot, MessageType.VOICE, message.voice.file_id)


@router.message(F.sticker)
async def relay_sticker(message: Message, bot: Bot) -> None:
    await _relay_message(message, bot, MessageType.STICKER, message.sticker.file_id)


@router.message(F.document)
async def relay_document(message: Message, bot: Bot) -> None:
    await _relay_message(message, bot, MessageType.DOCUMENT, message.document.file_id)


async def _relay_message(
    message: Message,
    bot: Bot,
    msg_type: MessageType,
    content: str,
) -> None:
    """Единая точка пересылки + логирования сообщений."""
    user_id = message.from_user.id

    async with AsyncSessionLocal() as session:
        matcher = _get_matching_service(session)
        chat_id = await matcher.get_current_chat_id(user_id)

        if not chat_id:
            await message.answer(
                "Ты не в чате. Нажми 🔍 Найти собеседника.",
                reply_markup=main_menu(),
            )
            return

        chat_repo = ChatRepository(session)
        partner_id = await chat_repo.get_partner_id(chat_id, user_id)

        if not partner_id:
            await message.answer("Ошибка: собеседник не найден.", reply_markup=main_menu())
            return

        # Логируем в БД
        await chat_repo.save_message(
            chat_id=chat_id,
            sender_id=user_id,
            msg_type=msg_type,
            content=content,
            tg_message_id=message.message_id,
        )

        # Обновляем счётчик сообщений
        user_repo = UserRepository(session)
        await user_repo.increment_stats(user_id, messages=1)

    # Пересылаем партнёру
    await _forward_by_type(bot, partner_id, message, msg_type)


async def _forward_by_type(
    bot: Bot,
    to_user_id: int,
    message: Message,
    msg_type: MessageType,
) -> None:
    """Пересылает сообщение нужного типа собеседнику."""
    caption = message.caption  # сохраняем подпись если есть

    match msg_type:
        case MessageType.TEXT:
            await bot.send_message(to_user_id, message.text)
        case MessageType.PHOTO:
            await bot.send_photo(to_user_id, message.photo[-1].file_id, caption=caption)
        case MessageType.VIDEO:
            await bot.send_video(to_user_id, message.video.file_id, caption=caption)
        case MessageType.VOICE:
            await bot.send_voice(to_user_id, message.voice.file_id)
        case MessageType.STICKER:
            await bot.send_sticker(to_user_id, message.sticker.file_id)
        case MessageType.DOCUMENT:
            await bot.send_document(to_user_id, message.document.file_id, caption=caption)
