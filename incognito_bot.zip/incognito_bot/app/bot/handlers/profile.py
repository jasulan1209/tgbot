from aiogram import Router, F
from aiogram.types import Message

from app.database.repositories.user_repo import UserRepository
from app.database.session import AsyncSessionLocal
from app.bot.keyboards.main import main_menu

router = Router(name="profile")


@router.message(F.text == "👤 Мой профиль")
async def show_profile(message: Message) -> None:
    async with AsyncSessionLocal() as session:
        repo = UserRepository(session)
        user = await repo.get_by_telegram_id(message.from_user.id)

    if not user:
        await message.answer("Сначала напиши /start", reply_markup=main_menu())
        return

    status_emoji = {"active": "🟢", "muted": "🟡", "banned": "🔴"}.get(user.status.value, "⚪")

    text = (
        f"👤 <b>Профиль</b>\n\n"
        f"🆔 ID: <code>{user.internal_id}</code>\n"
        f"📛 Никнейм: {user.nickname or '—'}\n"
        f"{status_emoji} Статус: {user.status.value}\n\n"
        f"📊 <b>Статистика</b>\n"
        f"💬 Чатов: {user.total_chats}\n"
        f"✉️ Сообщений: {user.total_messages}\n\n"
        f"📅 Регистрация: {user.created_at.strftime('%d.%m.%Y')}"
    )

    await message.answer(text, reply_markup=main_menu(), parse_mode="HTML")
