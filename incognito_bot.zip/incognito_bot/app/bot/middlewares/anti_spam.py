import time
from typing import Any, Callable, Awaitable

from aiogram import BaseMiddleware
from aiogram.types import TelegramObject, Message

from app.core.config import settings
from app.database.redis_client import get_redis


class AntiSpamMiddleware(BaseMiddleware):
    """
    Sliding window rate limiter на Redis.
    Ограничивает MAX_MESSAGES сообщений за WINDOW_SECONDS секунд.
    """

    async def __call__(
        self,
        handler: Callable[[TelegramObject, dict[str, Any]], Awaitable[Any]],
        event: TelegramObject,
        data: dict[str, Any],
    ) -> Any:
        if not isinstance(event, Message) or not event.from_user:
            return await handler(event, data)

        user_id = event.from_user.id
        now = time.time()
        window_start = now - settings.SPAM_WINDOW_SECONDS
        key = f"spam:{user_id}"

        redis = get_redis()
        async with redis.pipeline(transaction=True) as pipe:
            # Удаляем старые записи за пределами окна
            pipe.zremrangebyscore(key, "-inf", window_start)
            # Добавляем текущий timestamp
            pipe.zadd(key, {str(now): now})
            # Считаем сообщения в окне
            pipe.zcard(key)
            # Обновляем TTL
            pipe.expire(key, settings.SPAM_WINDOW_SECONDS * 2)
            results = await pipe.execute()

        message_count = results[2]

        if message_count > settings.SPAM_MAX_MESSAGES:
            await event.answer(
                f"⚠️ Слишком много сообщений. Подождите немного.",
                show_alert=False,
            )
            return  # блокируем обработку

        return await handler(event, data)
