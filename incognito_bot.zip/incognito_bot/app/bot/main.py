import asyncio
import logging

from aiogram import Bot, Dispatcher
from aiogram.enums import ParseMode
from aiogram.client.default import DefaultBotProperties

from app.core.config import settings
from app.database.session import create_tables
from app.database.redis_client import close_redis_pool
from app.bot.handlers import start, profile, chat
from app.bot.middlewares.ban_check import BanCheckMiddleware
from app.bot.middlewares.anti_spam import AntiSpamMiddleware

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
logger = logging.getLogger(__name__)


async def main() -> None:
    # Создаём таблицы (в проде заменить на Alembic)
    await create_tables()
    logger.info("Database tables ready")

    bot = Bot(
        token=settings.BOT_TOKEN,
        default=DefaultBotProperties(parse_mode=ParseMode.HTML),
    )
    dp = Dispatcher()

    # Middlewares — порядок важен: сначала бан, потом спам
    dp.message.middleware(BanCheckMiddleware())
    dp.message.middleware(AntiSpamMiddleware())
    dp.callback_query.middleware(BanCheckMiddleware())

    # Роутеры
    dp.include_router(start.router)
    dp.include_router(profile.router)
    dp.include_router(chat.router)

    logger.info("Starting bot polling...")
    try:
        await dp.start_polling(bot, allowed_updates=dp.resolve_used_update_types())
    finally:
        await close_redis_pool()
        await bot.session.close()
        logger.info("Bot stopped")


if __name__ == "__main__":
    asyncio.run(main())
