from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton, ReplyKeyboardMarkup, KeyboardButton
from aiogram.utils.keyboard import InlineKeyboardBuilder


def main_menu() -> ReplyKeyboardMarkup:
    """Главное меню — постоянная клавиатура."""
    return ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text="🔍 Найти собеседника")],
            [KeyboardButton(text="👤 Мой профиль")],
        ],
        resize_keyboard=True,
        one_time_keyboard=False,
    )


def searching_menu() -> ReplyKeyboardMarkup:
    """Меню во время поиска."""
    return ReplyKeyboardMarkup(
        keyboard=[[KeyboardButton(text="❌ Отменить поиск")]],
        resize_keyboard=True,
        one_time_keyboard=False,
    )


def chat_menu() -> ReplyKeyboardMarkup:
    """Меню во время активного чата."""
    return ReplyKeyboardMarkup(
        keyboard=[[KeyboardButton(text="🚫 Завершить чат")]],
        resize_keyboard=True,
        one_time_keyboard=False,
    )


def confirm_end_chat() -> InlineKeyboardMarkup:
    """Подтверждение завершения чата."""
    builder = InlineKeyboardBuilder()
    builder.button(text="✅ Да, завершить", callback_data="end_chat_confirm")
    builder.button(text="↩️ Продолжить", callback_data="end_chat_cancel")
    builder.adjust(2)
    return builder.as_markup()
