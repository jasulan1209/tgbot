"""
Matching Service — отвечает за Redis очередь поиска и создание пар.

Ключи Redis:
  search_queue          — ZSET (sorted set, score = timestamp вхождения)
  user:in_queue:{id}    — STRING, TTL 120s (флаг "юзер в очереди")
  user:in_chat:{id}     — STRING (флаг "юзер в активном чате")
"""

import json
import time
from dataclasses import dataclass

from redis.asyncio import Redis

from app.database.repositories.chat_repo import ChatRepository
from app.database.repositories.user_repo import UserRepository

QUEUE_KEY = "search_queue"
IN_QUEUE_PREFIX = "user:in_queue:"
IN_CHAT_PREFIX = "user:in_chat:"
QUEUE_TTL = 120  # секунд — после этого юзера выкидываем из очереди


@dataclass
class MatchResult:
    chat_id: int
    partner_id: int


class MatchingService:
    def __init__(self, redis: Redis, chat_repo: ChatRepository, user_repo: UserRepository) -> None:
        self._redis = redis
        self._chat_repo = chat_repo
        self._user_repo = user_repo

    async def join_queue(self, telegram_id: int) -> bool:
        """
        Добавляет юзера в очередь.
        Возвращает False если юзер уже в очереди или в чате.
        """
        if await self.is_in_chat(telegram_id):
            return False
        if await self.is_in_queue(telegram_id):
            return False

        payload = json.dumps({"user_id": telegram_id})
        score = time.time()

        async with self._redis.pipeline(transaction=True) as pipe:
            pipe.zadd(QUEUE_KEY, {payload: score})
            pipe.setex(f"{IN_QUEUE_PREFIX}{telegram_id}", QUEUE_TTL, "1")
            await pipe.execute()

        return True

    async def leave_queue(self, telegram_id: int) -> None:
        """Убирает юзера из очереди (если передумал искать)."""
        payload = json.dumps({"user_id": telegram_id})
        async with self._redis.pipeline(transaction=True) as pipe:
            pipe.zrem(QUEUE_KEY, payload)
            pipe.delete(f"{IN_QUEUE_PREFIX}{telegram_id}")
            await pipe.execute()

    async def try_match(self, telegram_id: int) -> MatchResult | None:
        """
        Пытается найти пару для telegram_id.
        Если находит — создаёт чат в БД и возвращает MatchResult.
        Если нет — возвращает None (юзер остаётся в очереди).
        """
        # Берём первых двух из очереди (по времени вхождения)
        entries = await self._redis.zrange(QUEUE_KEY, 0, 1, withscores=False)

        if len(entries) < 2:
            return None

        # Парсим оба entry
        first_data = json.loads(entries[0])
        second_data = json.loads(entries[1])

        user1_id = first_data["user_id"]
        user2_id = second_data["user_id"]

        # Не спаривать с самим собой (на случай багов)
        if user1_id == user2_id:
            return None

        # Атомарно удаляем обоих из очереди
        async with self._redis.pipeline(transaction=True) as pipe:
            pipe.zrem(QUEUE_KEY, entries[0], entries[1])
            pipe.delete(f"{IN_QUEUE_PREFIX}{user1_id}")
            pipe.delete(f"{IN_QUEUE_PREFIX}{user2_id}")
            await pipe.execute()

        # Создаём чат в MySQL
        chat = await self._chat_repo.create_chat(user1_id=user1_id, user2_id=user2_id)

        # Помечаем обоих как "в чате"
        async with self._redis.pipeline() as pipe:
            pipe.set(f"{IN_CHAT_PREFIX}{user1_id}", str(chat.id))
            pipe.set(f"{IN_CHAT_PREFIX}{user2_id}", str(chat.id))
            await pipe.execute()

        # Обновляем статистику
        await self._user_repo.increment_stats(user1_id, chats=1)
        await self._user_repo.increment_stats(user2_id, chats=1)

        partner_id = user2_id if telegram_id == user1_id else user1_id
        return MatchResult(chat_id=chat.id, partner_id=partner_id)

    async def end_chat(self, telegram_id: int, chat_id: int) -> int | None:
        """
        Завершает чат. Возвращает telegram_id партнёра (чтобы бот мог уведомить его).
        """
        partner_id = await self._chat_repo.get_partner_id(chat_id, telegram_id)

        await self._chat_repo.close_chat(chat_id)

        async with self._redis.pipeline() as pipe:
            pipe.delete(f"{IN_CHAT_PREFIX}{telegram_id}")
            if partner_id:
                pipe.delete(f"{IN_CHAT_PREFIX}{partner_id}")
            await pipe.execute()

        return partner_id

    async def is_in_queue(self, telegram_id: int) -> bool:
        return bool(await self._redis.exists(f"{IN_QUEUE_PREFIX}{telegram_id}"))

    async def is_in_chat(self, telegram_id: int) -> bool:
        return bool(await self._redis.exists(f"{IN_CHAT_PREFIX}{telegram_id}"))

    async def get_current_chat_id(self, telegram_id: int) -> int | None:
        val = await self._redis.get(f"{IN_CHAT_PREFIX}{telegram_id}")
        return int(val) if val else None

    async def get_queue_size(self) -> int:
        return await self._redis.zcard(QUEUE_KEY)

    async def cleanup_expired_queue(self) -> int:
        """
        Удаляет из очереди тех, у кого истёк TTL флага IN_QUEUE.
        Вызывается периодически из background task.
        """
        entries = await self._redis.zrange(QUEUE_KEY, 0, -1)
        removed = 0
        for entry in entries:
            data = json.loads(entry)
            uid = data["user_id"]
            if not await self._redis.exists(f"{IN_QUEUE_PREFIX}{uid}"):
                await self._redis.zrem(QUEUE_KEY, entry)
                removed += 1
        return removed
