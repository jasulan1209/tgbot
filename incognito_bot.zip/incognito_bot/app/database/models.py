from __future__ import annotations

from datetime import datetime
from enum import Enum as PyEnum

from sqlalchemy import (
    BigInteger, String, DateTime, ForeignKey,
    Integer, Text, Enum, func, Index,
)
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship


class Base(DeclarativeBase):
    pass


# ─── Enums ────────────────────────────────────────────────────────────────────

class UserStatus(str, PyEnum):
    ACTIVE = "active"
    MUTED = "muted"
    BANNED = "banned"


class ChatStatus(str, PyEnum):
    ACTIVE = "active"
    CLOSED = "closed"


class MessageType(str, PyEnum):
    TEXT = "text"
    PHOTO = "photo"
    VIDEO = "video"
    VOICE = "voice"
    STICKER = "sticker"
    DOCUMENT = "document"


class SessionStatus(str, PyEnum):
    ACTIVE = "active"
    CLOSED = "closed"


# ─── Models ───────────────────────────────────────────────────────────────────

class User(Base):
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    telegram_id: Mapped[int] = mapped_column(BigInteger, unique=True, index=True, nullable=False)
    internal_id: Mapped[str] = mapped_column(String(10), unique=True, index=True, nullable=False)
    nickname: Mapped[str | None] = mapped_column(String(64), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now(), nullable=False)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, server_default=func.now(), onupdate=func.now(), nullable=False
    )
    status: Mapped[UserStatus] = mapped_column(
        Enum(UserStatus), default=UserStatus.ACTIVE, nullable=False
    )
    # 0 = user, 1-4 = admin levels
    admin_level: Mapped[int] = mapped_column(Integer, default=0, nullable=False)

    # Статистика — дополнение к оригинальному промту
    total_chats: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    total_messages: Mapped[int] = mapped_column(Integer, default=0, nullable=False)

    chats_as_user1: Mapped[list[Chat]] = relationship(
        "Chat", foreign_keys="Chat.user1_id", back_populates="user1", lazy="noload"
    )
    chats_as_user2: Mapped[list[Chat]] = relationship(
        "Chat", foreign_keys="Chat.user2_id", back_populates="user2", lazy="noload"
    )

    def __repr__(self) -> str:
        return f"<User id={self.id} internal_id={self.internal_id} status={self.status}>"


class Chat(Base):
    __tablename__ = "chats"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    user1_id: Mapped[int] = mapped_column(
        BigInteger, ForeignKey("users.telegram_id", ondelete="RESTRICT"), index=True, nullable=False
    )
    user2_id: Mapped[int] = mapped_column(
        BigInteger, ForeignKey("users.telegram_id", ondelete="RESTRICT"), index=True, nullable=False
    )
    started_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now(), nullable=False)
    closed_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    status: Mapped[ChatStatus] = mapped_column(
        Enum(ChatStatus), default=ChatStatus.ACTIVE, nullable=False
    )

    user1: Mapped[User] = relationship("User", foreign_keys=[user1_id], back_populates="chats_as_user1", lazy="noload")
    user2: Mapped[User] = relationship("User", foreign_keys=[user2_id], back_populates="chats_as_user2", lazy="noload")
    messages: Mapped[list[Message]] = relationship("Message", back_populates="chat", lazy="noload")

    __table_args__ = (
        Index("ix_chats_status_started", "status", "started_at"),
    )

    def __repr__(self) -> str:
        return f"<Chat id={self.id} {self.user1_id}↔{self.user2_id} status={self.status}>"


class Message(Base):
    __tablename__ = "messages"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    chat_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("chats.id", ondelete="CASCADE"), index=True, nullable=False
    )
    sender_id: Mapped[int] = mapped_column(
        BigInteger, ForeignKey("users.telegram_id", ondelete="RESTRICT"), nullable=False
    )
    msg_type: Mapped[MessageType] = mapped_column(Enum(MessageType), nullable=False)
    content: Mapped[str] = mapped_column(Text, nullable=False)
    # Telegram message_id для возможного редактирования/удаления
    tg_message_id: Mapped[int | None] = mapped_column(Integer, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now(), nullable=False)

    chat: Mapped[Chat] = relationship("Chat", back_populates="messages", lazy="noload")

    __table_args__ = (
        Index("ix_messages_chat_created", "chat_id", "created_at"),
    )

    def __repr__(self) -> str:
        return f"<Message id={self.id} chat={self.chat_id} type={self.msg_type}>"


class ActiveSession(Base):
    """Быстрая таблица для проверки: в каком чате сейчас юзер."""
    __tablename__ = "active_sessions"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    user_id: Mapped[int] = mapped_column(
        BigInteger,
        ForeignKey("users.telegram_id", ondelete="CASCADE"),
        unique=True,
        index=True,
        nullable=False,
    )
    chat_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("chats.id", ondelete="CASCADE"), nullable=False
    )
    status: Mapped[SessionStatus] = mapped_column(
        Enum(SessionStatus), default=SessionStatus.ACTIVE, nullable=False
    )
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now(), nullable=False)

    def __repr__(self) -> str:
        return f"<ActiveSession user={self.user_id} chat={self.chat_id}>"
