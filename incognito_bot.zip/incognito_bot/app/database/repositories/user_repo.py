import random
import string

from sqlalchemy import select, update
from sqlalchemy.ext.asyncio import AsyncSession

from app.database.models import User, UserStatus


def _generate_internal_id(length: int = 3) -> str:
    """Генерирует internal_id вида A7J, HS1, XK9."""
    chars = string.ascii_uppercase + string.digits
    return "".join(random.choices(chars, k=length))


class UserRepository:
    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def get_by_telegram_id(self, telegram_id: int) -> User | None:
        result = await self._session.execute(
            select(User).where(User.telegram_id == telegram_id)
        )
        return result.scalar_one_or_none()

    async def get_by_internal_id(self, internal_id: str) -> User | None:
        result = await self._session.execute(
            select(User).where(User.internal_id == internal_id)
        )
        return result.scalar_one_or_none()

    async def create(self, telegram_id: int, nickname: str | None = None) -> User:
        internal_id = await self._generate_unique_internal_id()
        user = User(
            telegram_id=telegram_id,
            internal_id=internal_id,
            nickname=nickname,
        )
        self._session.add(user)
        await self._session.commit()
        await self._session.refresh(user)
        return user

    async def get_or_create(self, telegram_id: int, nickname: str | None = None) -> tuple[User, bool]:
        """Возвращает (user, created). created=True если пользователь новый."""
        user = await self.get_by_telegram_id(telegram_id)
        if user:
            return user, False
        user = await self.create(telegram_id, nickname)
        return user, True

    async def update_status(self, telegram_id: int, status: UserStatus) -> None:
        await self._session.execute(
            update(User)
            .where(User.telegram_id == telegram_id)
            .values(status=status)
        )
        await self._session.commit()

    async def update_nickname(self, telegram_id: int, nickname: str) -> None:
        await self._session.execute(
            update(User)
            .where(User.telegram_id == telegram_id)
            .values(nickname=nickname)
        )
        await self._session.commit()

    async def increment_stats(self, telegram_id: int, chats: int = 0, messages: int = 0) -> None:
        user = await self.get_by_telegram_id(telegram_id)
        if user:
            user.total_chats += chats
            user.total_messages += messages
            await self._session.commit()

    async def is_banned(self, telegram_id: int) -> bool:
        result = await self._session.execute(
            select(User.status).where(User.telegram_id == telegram_id)
        )
        status = result.scalar_one_or_none()
        return status == UserStatus.BANNED

    async def _generate_unique_internal_id(self) -> str:
        for _ in range(20):  # максимум 20 попыток
            candidate = _generate_internal_id()
            existing = await self.get_by_internal_id(candidate)
            if not existing:
                return candidate
        # При коллизиях увеличиваем длину
        return _generate_internal_id(length=5)
