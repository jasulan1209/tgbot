from datetime import datetime

from sqlalchemy import select, update, and_
from sqlalchemy.ext.asyncio import AsyncSession

from app.database.models import (
    Chat, ChatStatus,
    Message, MessageType,
    ActiveSession, SessionStatus,
)


class ChatRepository:
    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    # ─── Chat ─────────────────────────────────────────────────────────────────

    async def create_chat(self, user1_id: int, user2_id: int) -> Chat:
        chat = Chat(user1_id=user1_id, user2_id=user2_id, status=ChatStatus.ACTIVE)
        self._session.add(chat)
        await self._session.flush()  # получаем id до commit

        # Создаём сессии для обоих участников
        for uid in (user1_id, user2_id):
            session = ActiveSession(user_id=uid, chat_id=chat.id, status=SessionStatus.ACTIVE)
            self._session.add(session)

        await self._session.commit()
        await self._session.refresh(chat)
        return chat

    async def get_chat(self, chat_id: int) -> Chat | None:
        result = await self._session.execute(
            select(Chat).where(Chat.id == chat_id)
        )
        return result.scalar_one_or_none()

    async def close_chat(self, chat_id: int) -> None:
        await self._session.execute(
            update(Chat)
            .where(Chat.id == chat_id)
            .values(status=ChatStatus.CLOSED, closed_at=datetime.utcnow())
        )
        # Закрываем активные сессии
        await self._session.execute(
            update(ActiveSession)
            .where(ActiveSession.chat_id == chat_id)
            .values(status=SessionStatus.CLOSED)
        )
        await self._session.commit()

    async def get_active_chat_for_user(self, telegram_id: int) -> Chat | None:
        """Возвращает активный чат пользователя (если есть)."""
        result = await self._session.execute(
            select(Chat).where(
                and_(
                    Chat.status == ChatStatus.ACTIVE,
                    (Chat.user1_id == telegram_id) | (Chat.user2_id == telegram_id),
                )
            )
        )
        return result.scalar_one_or_none()

    # ─── ActiveSession ─────────────────────────────────────────────────────────

    async def get_active_session(self, telegram_id: int) -> ActiveSession | None:
        result = await self._session.execute(
            select(ActiveSession).where(
                and_(
                    ActiveSession.user_id == telegram_id,
                    ActiveSession.status == SessionStatus.ACTIVE,
                )
            )
        )
        return result.scalar_one_or_none()

    async def delete_session(self, telegram_id: int) -> None:
        session = await self.get_active_session(telegram_id)
        if session:
            await self._session.delete(session)
            await self._session.commit()

    # ─── Messages ──────────────────────────────────────────────────────────────

    async def save_message(
        self,
        chat_id: int,
        sender_id: int,
        msg_type: MessageType,
        content: str,
        tg_message_id: int | None = None,
    ) -> Message:
        msg = Message(
            chat_id=chat_id,
            sender_id=sender_id,
            msg_type=msg_type,
            content=content,
            tg_message_id=tg_message_id,
        )
        self._session.add(msg)
        await self._session.commit()
        return msg

    async def get_chat_messages(
        self,
        chat_id: int,
        limit: int = 50,
        offset: int = 0,
    ) -> list[Message]:
        result = await self._session.execute(
            select(Message)
            .where(Message.chat_id == chat_id)
            .order_by(Message.created_at.asc())
            .limit(limit)
            .offset(offset)
        )
        return list(result.scalars().all())

    async def get_partner_id(self, chat_id: int, my_telegram_id: int) -> int | None:
        """Возвращает telegram_id собеседника в данном чате."""
        chat = await self.get_chat(chat_id)
        if not chat:
            return None
        if chat.user1_id == my_telegram_id:
            return chat.user2_id
        if chat.user2_id == my_telegram_id:
            return chat.user1_id
        return None
